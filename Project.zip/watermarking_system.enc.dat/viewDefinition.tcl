if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name fast\
   -timing\
    [list ${::IMEX::libVar}/mmmc/fast.lib]
create_library_set -name slow\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib]
create_rc_corner -name Rc\
   -cap_table ${::IMEX::libVar}/mmmc/gpdk090.lef.extended.CapTbl\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0\
   -T 125\
   -qx_tech_file ${::IMEX::libVar}/mmmc/Rc/gpdk090_9l.tch
create_delay_corner -name MAX_DELAY\
   -library_set slow\
   -rc_corner Rc
create_delay_corner -name MIN_DELAY\
   -library_set fast\
   -rc_corner Rc
create_constraint_mode -name CONST\
   -sdc_files\
    [list /dev/null]
create_analysis_view -name WORSTCASE -constraint_mode CONST -delay_corner MAX_DELAY
create_analysis_view -name BESTCASE -constraint_mode CONST -delay_corner MIN_DELAY
set_analysis_view -setup [list WORSTCASE] -hold [list BESTCASE]
