
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point pixel_in[7] pixel_in[7] -type PI PI
add mapped point pixel_in[6] pixel_in[6] -type PI PI
add mapped point pixel_in[5] pixel_in[5] -type PI PI
add mapped point pixel_in[4] pixel_in[4] -type PI PI
add mapped point pixel_in[3] pixel_in[3] -type PI PI
add mapped point pixel_in[2] pixel_in[2] -type PI PI
add mapped point pixel_in[1] pixel_in[1] -type PI PI
add mapped point pixel_in[0] pixel_in[0] -type PI PI
add mapped point valid_in valid_in -type PI PI

//output ports
add mapped point watermarked_pixel_out[7] watermarked_pixel_out[7] -type PO PO
add mapped point watermarked_pixel_out[6] watermarked_pixel_out[6] -type PO PO
add mapped point watermarked_pixel_out[5] watermarked_pixel_out[5] -type PO PO
add mapped point watermarked_pixel_out[4] watermarked_pixel_out[4] -type PO PO
add mapped point watermarked_pixel_out[3] watermarked_pixel_out[3] -type PO PO
add mapped point watermarked_pixel_out[2] watermarked_pixel_out[2] -type PO PO
add mapped point watermarked_pixel_out[1] watermarked_pixel_out[1] -type PO PO
add mapped point watermarked_pixel_out[0] watermarked_pixel_out[0] -type PO PO
add mapped point valid_out valid_out -type PO PO

//inout ports




//Sequential Pins
add mapped point watermarked_pixel_out[7]/q watermarked_pixel_out_reg[7]/Q -type DFF DFF
add mapped point buffer_x2[7]/q buffer_x2_reg[7]/Q -type DFF DFF
add mapped point watermarked_pixel_out[6]/q watermarked_pixel_out_reg[6]/Q -type DFF DFF
add mapped point watermarked_pixel_out[5]/q watermarked_pixel_out_reg[5]/Q -type DFF DFF
add mapped point buffer_x2[6]/q buffer_x2_reg[6]/Q -type DFF DFF
add mapped point watermarked_pixel_out[0]/q watermarked_pixel_out_reg[0]/Q -type DFF DFF
add mapped point watermarked_pixel_out[1]/q watermarked_pixel_out_reg[1]/Q -type DFF DFF
add mapped point watermarked_pixel_out[4]/q watermarked_pixel_out_reg[4]/Q -type DFF DFF
add mapped point watermarked_pixel_out[3]/q watermarked_pixel_out_reg[3]/Q -type DFF DFF
add mapped point watermarked_pixel_out[2]/q watermarked_pixel_out_reg[2]/Q -type DFF DFF
add mapped point buffer_x2[5]/q buffer_x2_reg[5]/Q -type DFF DFF
add mapped point buffer_x2[4]/q buffer_x2_reg[4]/Q -type DFF DFF
add mapped point buffer_x2[1]/q buffer_x2_reg[1]/Q -type DFF DFF
add mapped point valid_out/q valid_out_reg/Q -type DFF DFF
add mapped point buffer_x2[3]/q buffer_x2_reg[3]/Q -type DFF DFF
add mapped point buffer_x2[0]/q buffer_x2_reg[0]/Q -type DFF DFF
add mapped point buffer_x2[2]/q buffer_x2_reg[2]/Q -type DFF DFF
add mapped point prev_pixel[0]/q prev_pixel_reg[0]/Q -type DFF DFF
add mapped point prev_pixel[6]/q prev_pixel_reg[6]/Q -type DFF DFF
add mapped point prev_pixel[2]/q prev_pixel_reg[2]/Q -type DFF DFF
add mapped point prev_pixel[7]/q prev_pixel_reg[7]/Q -type DFF DFF
add mapped point prev_pixel[1]/q prev_pixel_reg[1]/Q -type DFF DFF
add mapped point prev_pixel[5]/q prev_pixel_reg[5]/Q -type DFF DFF
add mapped point prev_pixel[4]/q prev_pixel_reg[4]/Q -type DFF DFF
add mapped point prev_pixel[3]/q prev_pixel_reg[3]/Q -type DFF DFF
add mapped point pixel_pair_toggle/q pixel_pair_toggle_reg/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
