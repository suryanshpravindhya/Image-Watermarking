
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point pixel_in[7] pixel_in[7] -type PI PI
add mapped point pixel_in[6] pixel_in[6] -type PI PI
add mapped point pixel_in[5] pixel_in[5] -type PI PI
add mapped point pixel_in[4] pixel_in[4] -type PI PI
add mapped point pixel_in[3] pixel_in[3] -type PI PI
add mapped point pixel_in[2] pixel_in[2] -type PI PI
add mapped point pixel_in[1] pixel_in[1] -type PI PI
add mapped point pixel_in[0] pixel_in[0] -type PI PI
add mapped point valid_in valid_in -type PI PI

//output ports
add mapped point ll_out[8] ll_out[8] -type PO PO
add mapped point ll_out[7] ll_out[7] -type PO PO
add mapped point ll_out[6] ll_out[6] -type PO PO
add mapped point ll_out[5] ll_out[5] -type PO PO
add mapped point ll_out[4] ll_out[4] -type PO PO
add mapped point ll_out[3] ll_out[3] -type PO PO
add mapped point ll_out[2] ll_out[2] -type PO PO
add mapped point ll_out[1] ll_out[1] -type PO PO
add mapped point ll_out[0] ll_out[0] -type PO PO
add mapped point valid_out valid_out -type PO PO

//inout ports




//Sequential Pins
add mapped point ll_out[8]/q ll_out_reg[8]/Q -type DFF DFF
add mapped point ll_out[7]/q ll_out_reg[7]/Q -type DFF DFF
add mapped point ll_out[6]/q ll_out_reg[6]/Q -type DFF DFF
add mapped point ll_out[5]/q ll_out_reg[5]/Q -type DFF DFF
add mapped point ll_out[4]/q ll_out_reg[4]/Q -type DFF DFF
add mapped point ll_out[3]/q ll_out_reg[3]/Q -type DFF DFF
add mapped point ll_out[2]/q ll_out_reg[2]/Q -type DFF DFF
add mapped point ll_out[1]/q ll_out_reg[1]/Q -type DFF DFF
add mapped point ll_out[0]/q ll_out_reg[0]/Q -type DFF DFF
add mapped point valid_out/q valid_out_reg/Q -type DFF DFF
add mapped point prev_pixel[0]/q prev_pixel_reg[0]/Q -type DFF DFF
add mapped point prev_pixel[1]/q prev_pixel_reg[1]/Q -type DFF DFF
add mapped point prev_pixel[2]/q prev_pixel_reg[2]/Q -type DFF DFF
add mapped point prev_pixel[7]/q prev_pixel_reg[7]/Q -type DFF DFF
add mapped point prev_pixel[5]/q prev_pixel_reg[5]/Q -type DFF DFF
add mapped point prev_pixel[3]/q prev_pixel_reg[3]/Q -type DFF DFF
add mapped point prev_pixel[4]/q prev_pixel_reg[4]/Q -type DFF DFF
add mapped point prev_pixel[6]/q prev_pixel_reg[6]/Q -type DFF DFF
add mapped point count[8]/q count_reg[8]/Q -type DFF DFF
add mapped point count[10]/q count_reg[10]/Q -type DFF DFF
add mapped point count[9]/q count_reg[9]/Q -type DFF DFF
add mapped point count[11]/q count_reg[11]/Q -type DFF DFF
add mapped point count[12]/q count_reg[12]/Q -type DFF DFF
add mapped point count[13]/q count_reg[13]/Q -type DFF DFF
add mapped point count[14]/q count_reg[14]/Q -type DFF DFF
add mapped point count[15]/q count_reg[15]/Q -type DFF DFF
add mapped point count[16]/q count_reg[16]/Q -type DFF DFF
add mapped point count[17]/q count_reg[17]/Q -type DFF DFF
add mapped point count[18]/q count_reg[18]/Q -type DFF DFF
add mapped point count[19]/q count_reg[19]/Q -type DFF DFF
add mapped point count[20]/q count_reg[20]/Q -type DFF DFF
add mapped point count[1]/q count_reg[1]/Q -type DFF DFF
add mapped point count[3]/q count_reg[3]/Q -type DFF DFF
add mapped point count[21]/q count_reg[21]/Q -type DFF DFF
add mapped point count[22]/q count_reg[22]/Q -type DFF DFF
add mapped point count[23]/q count_reg[23]/Q -type DFF DFF
add mapped point count[4]/q count_reg[4]/Q -type DFF DFF
add mapped point count[24]/q count_reg[24]/Q -type DFF DFF
add mapped point count[25]/q count_reg[25]/Q -type DFF DFF
add mapped point count[26]/q count_reg[26]/Q -type DFF DFF
add mapped point count[2]/q count_reg[2]/Q -type DFF DFF
add mapped point count[27]/q count_reg[27]/Q -type DFF DFF
add mapped point count[28]/q count_reg[28]/Q -type DFF DFF
add mapped point count[29]/q count_reg[29]/Q -type DFF DFF
add mapped point count[5]/q count_reg[5]/Q -type DFF DFF
add mapped point count[6]/q count_reg[6]/Q -type DFF DFF
add mapped point count[30]/q count_reg[30]/Q -type DFF DFF
add mapped point count[7]/q count_reg[7]/Q -type DFF DFF
add mapped point count[31]/q count_reg[31]/Q -type DFF DFF
add mapped point count[0]/q count_reg[0]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
