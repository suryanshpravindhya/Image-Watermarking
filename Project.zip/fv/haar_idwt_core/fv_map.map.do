
//input ports
add mapped point s[8] s[8] -type PI PI
add mapped point s[7] s[7] -type PI PI
add mapped point s[6] s[6] -type PI PI
add mapped point s[5] s[5] -type PI PI
add mapped point s[4] s[4] -type PI PI
add mapped point s[3] s[3] -type PI PI
add mapped point s[2] s[2] -type PI PI
add mapped point s[1] s[1] -type PI PI
add mapped point s[0] s[0] -type PI PI
add mapped point d[8] d[8] -type PI PI
add mapped point d[7] d[7] -type PI PI
add mapped point d[6] d[6] -type PI PI
add mapped point d[5] d[5] -type PI PI
add mapped point d[4] d[4] -type PI PI
add mapped point d[3] d[3] -type PI PI
add mapped point d[2] d[2] -type PI PI
add mapped point d[1] d[1] -type PI PI
add mapped point d[0] d[0] -type PI PI

//output ports
add mapped point x1[7] x1[7] -type PO PO
add mapped point x1[6] x1[6] -type PO PO
add mapped point x1[5] x1[5] -type PO PO
add mapped point x1[4] x1[4] -type PO PO
add mapped point x1[3] x1[3] -type PO PO
add mapped point x1[2] x1[2] -type PO PO
add mapped point x1[1] x1[1] -type PO PO
add mapped point x1[0] x1[0] -type PO PO
add mapped point x2[7] x2[7] -type PO PO
add mapped point x2[6] x2[6] -type PO PO
add mapped point x2[5] x2[5] -type PO PO
add mapped point x2[4] x2[4] -type PO PO
add mapped point x2[3] x2[3] -type PO PO
add mapped point x2[2] x2[2] -type PO PO
add mapped point x2[1] x2[1] -type PO PO
add mapped point x2[0] x2[0] -type PO PO

//inout ports




//Sequential Pins



//Black Boxes



//Empty Modules as Blackboxes
